// sečte dvě čísla
export function add(num1, num2) {
    const result = num1 + num2;
    return result;
}

// odečte dvě čísla
export function substract(num1, num2) {
    const result = num1 - num2;
    return result;
}

// vydělí dvě čísla
export function divide(num1, num2) {
    const result = num1 / num2;
    return result;
}

// vynásobí dvě čísla
export function multiply(num1, num2) {
    const result = num1 * num2;
    return result;
}